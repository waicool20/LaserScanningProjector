__author__ = 'karlp'

def config_switch():
    pass
