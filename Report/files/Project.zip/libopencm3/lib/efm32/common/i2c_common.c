/** @addtogroup i2c_file I2C peripheral API
 * @ingroup peripheral_apis
 * @brief I²C helper functions.
 *
 * <b>NO</b> helper functions exist. Only header definitions are available.
 * Delete these lines if/when you add actual helper APIs.
 * @copyright See @ref lgpl_license
 */

#include <libopencm3/efm32/i2c.h>

/**@{*/

/**@}*/

