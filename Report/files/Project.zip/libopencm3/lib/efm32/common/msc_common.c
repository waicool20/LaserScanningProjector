/** @addtogroup msc_file MSC peripheral API
 * @ingroup peripheral_apis
 * @brief Memory Systems Controller helper functions.
 *
 * <b>NO</b> helper functions exist. Only header definitions are available.
 * Delete these lines if/when you add actual helper APIs.
 * @copyright See @ref lgpl_license
 */

#include <libopencm3/efm32/msc.h>

/**@{*/

/**@}*/

